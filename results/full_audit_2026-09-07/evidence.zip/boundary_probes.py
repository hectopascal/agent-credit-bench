import importlib.util
import json
import math
import random
from pathlib import Path
from agent_credit_bench.benchmark import run_benchmark
from agent_credit_bench.envs import RecoveryEnv,VariableHorizonEnv,StopProbabilityPolicy
from agent_credit_bench.estimators import *
from agent_credit_bench.policy import UniformPolicy
from agent_credit_bench.metrics import rmse,centered_rmse,leakage,sign_accuracy,spearman
from agent_credit_bench.sampling import sample_trajectories
from agent_credit_bench.integrations.bridge import play_episode,episode_record,trajectory_from_record,minimum_episode_return
from agent_credit_bench.types import Step,Trajectory

# Fail-closed estimator-output shape and nonfinite checks.
class Invalid:
 name='invalid'
 def __init__(self,fn):self.fn=fn
 def estimate(self,ctx):return self.fn(ctx)
cases=[lambda c:(),lambda c:tuple(() for t in c.trajectories)]
for value in [math.nan,math.inf,-math.inf]:
 cases.append(lambda c,v=value:tuple(tuple(v for s in t.steps) for t in c.trajectories))
for fn in cases:
 try: run_benchmark(RecoveryEnv(),UniformPolicy(),Invalid(fn),8,[0])
 except ValueError: pass
 else: raise AssertionError('invalid credits accepted')
print('PASS: estimator alignment/nonfinite boundary probes')

# Mutation of valid records: reject impossible actions, rewards, chronology, totals.
s=play_episode(RecoveryEnv(),lambda messages:'BAD RECOVER',seed=0)
base=episode_record(s,'recovery')
for field,value in [('action','UNKNOWN'),('reward',-7),('timestep',True),('state','other'),('terminated',True),('next_state','other')]:
 record=json.loads(json.dumps(base)); record['turns'][0][field]=value
 try: trajectory_from_record(record,mdp=RecoveryEnv())
 except ValueError:pass
 else:raise AssertionError(('accepted mutation',field))
for change in ['empty','partial','extra','wrong_total']:
 record=json.loads(json.dumps(base))
 if change=='empty':record['turns']=[]
 if change=='partial':record['turns']=record['turns'][:1]
 if change=='extra':record['turns'].append(record['turns'][-1])
 if change=='wrong_total':record['total_return']=9
 try:trajectory_from_record(record,mdp=RecoveryEnv())
 except ValueError:pass
 else:raise AssertionError(('accepted mutation',change))
print('PASS: 10 corrupt log mutations rejected')

# Scale/order/cancellation probes; print deviations as one numerical family.
for scale in [1.,1e-160,1e160]:
 try:observed=rmse([scale,-scale],[0.,0.])
 except Exception as e:observed=type(e).__name__
 print('RMSE scale',scale,'expected',scale,'observed',observed)

from helpers import TableMDP
from agent_credit_bench.types import Transition
mdp=TableMDP(1,'root',{(0,'root','LOW'):(Transition('done',1e16,1.,True),),(0,'root','HIGH'):(Transition('done',1e16+2,1.,True),)})
batch=tuple(Trajectory((Step(0,'root',a,r,'done',True),)) for a,r in [('LOW',1e16),('HIGH',1e16+2)])
ctx=EstimatorContext(mdp,UniformPolicy(),batch)
for estimator in [BatchCenteredBroadcast(),TurnLOO(),GRPOStyleNormalized(),GiGPOStyle()]:
 print('Offset batch',estimator.name,estimator.estimate(ctx))
