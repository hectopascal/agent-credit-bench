import csv,json,math
from pathlib import Path
from agent_credit_bench.envs import VariableHorizonEnv,StopProbabilityPolicy,DelayedEffectEnv
from agent_credit_bench.estimators import EstimatorContext,BatchCenteredBroadcast,TurnLOO,OracleAdvantage
from agent_credit_bench.types import Trajectory,Step
from agent_credit_bench.oracle import solve_exact_values
from agent_credit_bench.gradients import exact_policy_gradient,batch_gradient,norm
from agent_credit_bench.benchmark import run_benchmark
from agent_credit_bench.policy import UniformPolicy

out=Path('/tmp/agent-credit-bench-full-audit')
horizon=8;n=4;p=.65
mdp=VariableHorizonEnv(tuple((0.,2.,1.,3.)[i%4] for i in range(horizon)))
policy=StopProbabilityPolicy(p)
trajectories=[];probs=[]
for stop in range(horizon):
 trajectories.append(Trajectory(tuple(Step(t,'alive','CONTINUE',0.,'alive',False) for t in range(stop))+(Step(stop,'alive','STOP',mdp.stop_rewards[stop],'done',True),)))
 probs.append((1-p)**stop*(p if stop<horizon-1 else 1))
gstar=exact_policy_gradient(mdp,policy,solve_exact_values(mdp,policy));scale=norm(gstar)**2

def compositions(total,slots):
 if slots==1:yield (total,);return
 for count in range(total+1):
  for rest in compositions(total-count,slots-1):yield (count,)+rest

expected={};mass_sum=0.;cases=0
for counts in compositions(n,horizon):
 mass=math.factorial(n)
 batch=[]
 for count,prob,trajectory in zip(counts,probs,trajectories):
  mass=mass/math.factorial(count)*prob**count
  batch.extend([trajectory]*count)
 mass_sum+=mass;cases+=1
 ctx=EstimatorContext(mdp,policy,tuple(batch))
 for est in [BatchCenteredBroadcast(),TurnLOO()]:
  g=batch_gradient(mdp,policy,ctx.trajectories,est.estimate(ctx))
  loss=sum((g.get(k,0.)-gstar.get(k,0.))**2 for k in g.keys()|gstar.keys())/scale
  expected[est.name]=expected.get(est.name,0.)+mass*loss
assert abs(mass_sum-1)<1e-12
print('Exact expected normalized MSE:',cases,'count vectors',expected)
with open('results/variable_horizon_sweep.csv') as f:
 sampled={r['estimator']:float(r['normalized_gradient_mse']) for r in csv.DictReader(f) if r['horizon']=='8' and r['stop_probability']=='0.65' and r['batch_size']=='4'}
print('Published empirical MSE:',sampled)

class Shifted:
 name='oracle_plus_one'
 def estimate(self,c):return tuple(tuple(a+1 for a in row) for row in OracleAdvantage().estimate(c))
shift={}
for est in [OracleAdvantage(),Shifted()]:
 r=run_benchmark(DelayedEffectEnv(8),UniformPolicy(),est,200,range(30))
 shift[est.name]={'variance':r.gradient_variance,'relative_mean_gradient_error':r.relative_mean_gradient_error,'centered_rmse':max(x.centered_rmse for x in r.seed_metrics)}
print('Baseline shift:',shift)
(out/'claims-results.json').write_text(json.dumps({'frontier_expected':expected,'frontier_sampled':sampled,'shift':shift},indent=2)+'\n')
