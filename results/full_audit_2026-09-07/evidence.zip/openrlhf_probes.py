import random,math,statistics
from agent_credit_bench.envs import VariableHorizonEnv,StopProbabilityPolicy
from agent_credit_bench.sampling import sample_trajectories
from agent_credit_bench.estimators import EstimatorContext,BatchCenteredBroadcast
from agent_credit_bench.integrations.openrlhf import OpenRLHFOutcome,OpenRLHFGAE
from agent_credit_bench.oracle import solve_exact_values
rng=random.Random(97533)
worst=0.
for case in range(100):
 m=VariableHorizonEnv(tuple(rng.uniform(-3,3) for _ in range(rng.randint(2,7))))
 p=StopProbabilityPolicy(rng.uniform(.05,.95))
 ts=sample_trajectories(m,p,rng.randint(2,30),case)
 ctx=EstimatorContext(m,p,ts)
 expected=BatchCenteredBroadcast().estimate(ctx)
 got=OpenRLHFOutcome('rloo').estimate(ctx)
 assert max(abs(a-b) for ra,rb in zip(got,expected) for a,b in zip(ra,rb))<1e-12
 rewards=[t.total_return for t in ts]
 mean,sd=statistics.fmean(rewards),statistics.stdev(rewards)
 got=OpenRLHFOutcome('group_norm').estimate(ctx)
 for ret,row in zip(rewards,got):
  error=max(abs(c-(ret-mean)/(sd+1e-9)) for c in row)
  if error>=1e-9:
   print('Group norm discrepancy',case,'error',error,'std',sd,'reward',ret,'expected',(ret-mean)/(sd+1e-9),'got',row[0])
   assert error<1e-6
 gamma=rng.choice([.0,.4,1.]); lam=rng.choice([.0,.3,.95,1.])
 critic='exact' if gamma==1. else 'zero'
 values=solve_exact_values(m,p)
 raw=[]
 for trajectory in ts:
  suffix=0.;reverse=[]
  for step in reversed(trajectory.steps):
   v=values.state_values[step.timestep,step.state] if critic=='exact' else 0.
   future=values.state_values[step.timestep+1,step.next_state] if critic=='exact' and not step.terminated and step.timestep+1<m.horizon else 0.
   suffix=step.reward+gamma*future-v+gamma*lam*suffix
   reverse.append(suffix)
  raw.extend(reversed(reverse))
 center=statistics.fmean(raw)
 got=[c for row in OpenRLHFGAE(critic=critic,gamma=gamma,lam=lam,no_std_norm=True).estimate(ctx) for c in row]
 error=max(abs(a-(b-center)) for a,b in zip(got,raw))
 worst=max(worst,error)
 assert error<2e-6,(case,error,gamma,lam)
print('PASS: 100 randomized terminal-reward batches, OpenRLHF RLOO/group norm and recursive GAE; maximum centered-GAE error',worst)
