import math
import random
from agent_credit_bench.oracle import solve_exact_values
from agent_credit_bench.gradients import exact_policy_gradient
from agent_credit_bench.policy import TabularPolicy
from agent_credit_bench.types import Transition
from helpers import TableMDP

rng = random.Random(328947)
worst_error = 0.0
for case in range(200):
    horizon = rng.randint(1, 4)
    table, probabilities = {}, {}
    for t in range(horizon):
        for s in (['root'] if t == 0 else ['left', 'right']):
            p = rng.uniform(.05, .95)
            probabilities[t,s] = {'A':p,'B':1-p}
            for a in ['A','B']:
                q = rng.random()
                table[t,s,a] = tuple(
                    Transition(ns, rng.uniform(-3,3), w,
                               t == horizon-1 or rng.random() < .2)
                    for ns,w in [('left',q),('right',1-q)]
                )
    mdp = TableMDP(horizon,'root',table)
    policy = TabularPolicy(probabilities)
    expected = {}
    def enumerate_paths(t,s,mass,ret,score):
        for a,p in probabilities[t,s].items():
            next_score = dict(score)
            for b,pb in probabilities[t,s].items():
                key = (t,s,b)
                next_score[key] = next_score.get(key,0.) + (a==b)-pb
            for tr in table[t,s,a]:
                next_mass = mass*p*tr.probability
                next_ret = ret+tr.reward
                if tr.terminated:
                    for key,value in next_score.items():
                        expected[key] = expected.get(key,0.)+next_mass*next_ret*value
                else:
                    enumerate_paths(t+1,tr.next_state,next_mass,next_ret,next_score)
    enumerate_paths(0,'root',1.,0.,{})
    actual = exact_policy_gradient(mdp,policy,solve_exact_values(mdp,policy))
    for key in expected.keys() | actual.keys():
        error = abs(expected.get(key,0.)-actual.get(key,0.))
        worst_error = max(error,worst_error)
        assert error < 1e-12, (case,key,expected.get(key),actual.get(key))
print(f'200 random MDPs: exact gradient agrees with exhaustive trajectory-return differentiation; worst absolute error {worst_error:.3g}')
