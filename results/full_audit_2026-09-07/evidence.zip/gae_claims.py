from agent_credit_bench.envs import RecoveryEnv,DelayedEffectEnv
from agent_credit_bench.policy import UniformPolicy
from agent_credit_bench.sampling import sample_trajectories
from agent_credit_bench.estimators import EstimatorContext
from agent_credit_bench.integrations.verl import VerlGAE
m,p=RecoveryEnv(),UniformPolicy();ts=sample_trajectories(m,p,2000,0);ctx=EstimatorContext(m,p,ts)
for lam in [0.,.49,.75,1.]:
 credits=VerlGAE(lam=lam).estimate(ctx)
 selected=[row for t,row in zip(ts,credits) if len(t.steps)==2 and t.steps[1].action=='RECOVER' and t.total_return==1.]
 print('lambda',lam,'selected BAD/RECOVER',selected[0])
m=DelayedEffectEnv(4);ts=sample_trajectories(m,p,200,0);ctx=EstimatorContext(m,p,ts)
for lam in [0.,1.]:
 credits=VerlGAE(lam=lam).estimate(ctx)
 distractors=[row[1] for row in credits]
 print('Delayed intermediate lambda',lam,'credit range',min(distractors),max(distractors))
