"""Correctness expectations; these tests reproduce outstanding audit findings."""
import asyncio

import pytest
from agent_credit_bench.estimators import EstimatorContext, MonteCarloAdvantage
from agent_credit_bench.gradients import exact_policy_gradient
from agent_credit_bench.oracle import solve_exact_values
from agent_credit_bench.policy import UniformPolicy
from agent_credit_bench.sampling import sample_trajectories
from agent_credit_bench.types import Transition
from helpers import TableMDP


def chain_or_quit(rewards):
    return TableMDP(3, 'root', {
        (0, 'root', 'CHAIN'): (Transition('middle', rewards[0], 1., False),),
        (0, 'root', 'QUIT'): (Transition('done', 0., 1., True),),
        (1, 'middle', 'GO'): (Transition('last', rewards[1], 1., False),),
        (2, 'last', 'END'): (Transition('done', rewards[2], 1., True),),
    })


def test_verifiers_truncation_cannot_outscore_every_legal_completion(tmp_path):
    from credit_bench_env import load_environment
    from test_verifiers_integration import run_rollout

    env = load_environment(
        env='variable_horizon',
        env_params={'stop_rewards': [-1., -1.], 'continue_reward': 0.},
        num_train_examples=1, num_eval_examples=1,
        max_turns=2, episodes_path=str(tmp_path / 'episodes.jsonl'),
    )
    state = run_rollout(env, ['CONTINUE', 'STOP'])
    asyncio.run(env.rubric.score_rollout(state))
    # Every legal complete path returns -1. The generated final STOP is valid.
    assert state['reward'] == -1.


def test_monte_carlo_converges_with_cancelling_dense_rewards():
    mdp, policy = chain_or_quit((1., 1e16, -1e16)), UniformPolicy()
    values = solve_exact_values(mdp, policy)
    trajectories = sample_trajectories(mdp, policy, 16, 0)
    context = EstimatorContext(mdp, policy, trajectories)
    credits = MonteCarloAdvantage(num_rollouts=1024).estimate(context)
    for trajectory, row in zip(trajectories, credits, strict=True):
        step = trajectory.steps[0]
        expected = values.advantages[(0, step.state, step.action)]
        assert row[0] == pytest.approx(expected, abs=.1)


def test_multiturn_oracle_matches_stable_episode_returns():
    mdp, policy = chain_or_quit((1e16, 1., -1e16)), UniformPolicy()
    trajectories = sample_trajectories(mdp, policy, 16, 0)
    assert {t.total_return for t in trajectories} == {0., 1.}
    # Expected return is P(CHAIN), so its two-logit softmax gradient is +/- .25.
    values = solve_exact_values(mdp, policy)
    gradient = exact_policy_gradient(mdp, policy, values)
    assert gradient[(0, 'root', 'CHAIN')] == .25
    assert gradient[(0, 'root', 'QUIT')] == -.25


def test_group_baselines_are_invariant_to_a_common_return_offset():
    from agent_credit_bench.estimators import BatchCenteredBroadcast, TurnLOO
    from agent_credit_bench.types import Step, Trajectory
    mdp=TableMDP(1,'root',{(0,'root','LOW'):(Transition('done',1e16,1.,True),),(0,'root','HIGH'):(Transition('done',1e16+2,1.,True),)})
    batch=tuple(Trajectory((Step(0,'root',a,r,'done',True),)) for a,r in [('LOW',1e16),('HIGH',1e16+2)])
    context=EstimatorContext(mdp,UniformPolicy(),batch)
    for estimator in (BatchCenteredBroadcast(),TurnLOO()):
        assert estimator.estimate(context) == ((-2.,),(2.,))


@pytest.mark.parametrize('scale',[1e-170,1e160])
def test_rmse_preserves_representable_error_scale(scale):
    from agent_credit_bench.metrics import rmse
    assert rmse([scale,-scale],[0.,0.]) == pytest.approx(scale,rel=1e-12,abs=0.)


def test_recovery_cli_can_report_a_batch_without_good_trajectories(tmp_path,monkeypatch):
    import importlib.util
    import sys
    from pathlib import Path
    path=Path.cwd()/'experiments/recovery_diagnostic.py'
    spec=importlib.util.spec_from_file_location('recovery_cli_audit',path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    monkeypatch.setattr(sys,'argv',[str(path),'--batch-size','2','--num-seeds','1','--seed','0','--out',str(tmp_path/'plot.png'),'--csv-out',str(tmp_path/'metrics.csv')])
    mod.main()
    assert (tmp_path/'metrics.csv').exists()
