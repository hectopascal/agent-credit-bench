import asyncio
import math
import random
import statistics
from types import SimpleNamespace
import sys
from pathlib import Path

sys.path.insert(0, str(Path.cwd() / 'recipes/verl_bridge'))
from bridge_agent_loop import CreditBenchBridgeLoop
from verl.trainer.ppo import core_algos
import torch
from agent_credit_bench.estimators import EstimatorContext, BatchCenteredBroadcast
from agent_credit_bench.integrations.verl import VerlGAE, VerlGRPO, VerlRLOO
from agent_credit_bench.integrations.trl import TrlGRPO, TrlRLOO
from agent_credit_bench.envs import VariableHorizonEnv, StopProbabilityPolicy
from agent_credit_bench.sampling import sample_trajectories

# Validate public adapters on randomized dense rewards and variable-length batches.
rng = random.Random(887126)
for case in range(100):
    mdp = VariableHorizonEnv(tuple(rng.uniform(-3,3) for _ in range(rng.randint(2,7))), rng.uniform(-1,1))
    policy = StopProbabilityPolicy(rng.uniform(.05,.95))
    batch = sample_trajectories(mdp,policy,rng.randint(2,30),case)
    context = EstimatorContext(mdp,policy,batch)
    baseline = BatchCenteredBroadcast().estimate(context)
    for estimator in [VerlRLOO(),TrlRLOO()]:
        credits=estimator.estimate(context)
        assert max(abs(a-b) for ra,rb in zip(credits,baseline) for a,b in zip(ra,rb)) < 1e-12
    for estimator,epsilon in [(VerlGRPO(),1e-6),(TrlGRPO(),1e-4)]:
        credits=estimator.estimate(context)
        returns=[t.total_return for t in batch]
        m,sd=statistics.fmean(returns),statistics.stdev(returns)
        for ret,row in zip(returns,credits):
            assert all(abs(c-(ret-m)/(sd+epsilon))<1e-6 for c in row)
    # lambda=0: independently compute one-step TD residuals and sample whitening.
    from agent_credit_bench.oracle import solve_exact_values
    exact=solve_exact_values(mdp,policy)
    deltas=[]
    for tr in batch:
        for s in tr.steps:
            future=0. if s.terminated or s.timestep+1==mdp.horizon else exact.state_values[s.timestep+1,s.next_state]
            deltas.append(s.reward+future-exact.state_values[s.timestep,s.state])
    n=len(deltas)
    mean=math.fsum(deltas)/(n+1e-8)
    variance=math.fsum((x-mean)**2 for x in deltas)/(n+1e-8)*n/(n-1)
    expected=[(x-mean)/math.sqrt(variance+1e-8) for x in deltas]
    got=[c for row in VerlGAE(lam=0.).estimate(context) for c in row]
    assert max(abs(a-b) for a,b in zip(expected,got))<1e-8
print('PASS: 100 randomized dense-reward batches, verl/TRL RLOO and GRPO, verl GAE TD residuals')

async def bridge_output(reply):
    loop=object.__new__(CreditBenchBridgeLoop)
    loop.response_length=3
    loop.turn_separator=[]
    async def template(messages,**kwargs):
        return [201,202,203] if kwargs.get('remove_system_prompt') else [101]
    async def generate(**kwargs):
        return SimpleNamespace(token_ids=[1])
    loop.apply_chat_template=template
    loop.server_manager=SimpleNamespace(generate=generate)
    loop.tokenizer=SimpleNamespace(decode=lambda *args,**kwargs:reply)
    return await loop.run({},extra_info={'env':'variable_horizon','env_params':{'stop_rewards':[-1.,-1.],'continue_reward':0.}})
truncated=asyncio.run(bridge_output('CONTINUE'))
complete=asyncio.run(bridge_output('STOP'))
print('Bridge truncated:',truncated.response_ids,truncated.response_mask,truncated.reward_score)
print('Bridge complete:',complete.response_ids,complete.response_mask,complete.reward_score)
rewards=torch.zeros((2,3),dtype=torch.float64)
masks=torch.zeros_like(rewards)
for i,out in enumerate([truncated,complete]):
    masks[i,:len(out.response_mask)]=torch.tensor(out.response_mask)
    # Matches AgentLoopWorker's rm_scores placement and AgentLoopOutput.as_dict.
    rewards[i,len(out.response_ids)-1]=out.reward_score
for name,call in [
    ('GAE',lambda:core_algos.compute_gae_advantage_return(rewards,torch.zeros_like(rewards),masks,1.,1.)),
    ('REINFORCE++',lambda:core_algos.compute_reinforce_plus_plus_outcome_advantage(rewards,masks,config=SimpleNamespace(gamma=1.))),
]:
    advantages,returns=call()
    print(name,'generated-token returns:',returns[:,0].tolist(),'advantages:',advantages[:,0].tolist())
