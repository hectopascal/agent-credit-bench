import ast
import json
import re
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit

root=Path.cwd()
class Page(HTMLParser):
    def __init__(self): super().__init__(); self.ids=[]; self.links=[]
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if 'id' in attrs:self.ids.append(attrs['id'])
        self.links.extend(attrs[k] for k in ('href','src') if k in attrs)
p=Page(); p.feed((root/'site/index.html').read_text())
assert len(p.ids)==len(set(p.ids))
for link in p.links:
    u=urlsplit(link)
    if u.scheme or u.netloc:continue
    if u.fragment and not u.path: assert u.fragment in p.ids,link
    elif u.path:
        target=root/u.path if u.path.startswith('results/') or u.path=='llms.txt' else root/'site'/u.path
        assert target.is_file(),(link,target)
source=(root/'site/index.html').read_text()
for block in re.findall(r'<script type="application/ld\+json">(.*?)</script>',source,re.S):json.loads(block)
print('PASS: assembled-site local links, fragments, unique IDs and JSON-LD')

files=list((root/'src').rglob('*.py'))+list((root/'experiments').glob('*.py'))+list((root/'recipes').rglob('*.py'))+list((root/'scripts').glob('*.py'))
for file in files:ast.parse(file.read_text(),filename=str(file))
print('PASS:',len(files),'production/experiment/recipe/script Python files parse')
