import base64,hashlib,importlib.metadata as md,json,sys
results=[]
for name in sys.argv[1:]:
 d=md.distribution(name)
 for file in d.files or []:
  s=str(file)
  if any(s.endswith(x) for x in ['trainer/ppo/core_algos.py','utils/torch_functional.py','experimental/agent_loop/agent_loop.py','trainer/grpo_trainer.py','trainer/rloo_trainer.py','trainer/utils.py','trainer/ppo_utils/experience_maker.py','models/utils.py']):
   actual=base64.urlsafe_b64encode(hashlib.sha256(d.locate_file(file).read_bytes()).digest()).decode().rstrip('=')
   results.append({'package':name,'version':d.version,'file':s,'record_hash_matches':bool(file.hash and file.hash.value==actual)})
print(json.dumps(results,indent=2))
assert all(x['record_hash_matches'] for x in results)
